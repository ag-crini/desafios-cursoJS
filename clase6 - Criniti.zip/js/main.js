//clases
class Mueble{
    constructor(altura, longitud, profundidad, estantes, cajones){
        this.altura= parseInt (altura);
        this.longitud= parseInt (longitud);
        this.profundidad= parseInt(profundidad);
        this.estantes= parseInt(estantes);
    }
    perimetro (){
        return ((this.altura*4)+(this.longitud*4)+(this.profundidad*4))
    }
    perimetroTotal (){
        return ((this.altura*4)+(this.longitud*4)+(this.profundidad*4)+(((this.longitud+this.profundidad)*2)*this.estantes))
    }
    superficieIndividual(){
        return (this.longitud*this.profundidad)
    }
    superficieTotal(){
        return ((this.longitud*this.profundidad)*2+(this.longitud*this.profundidad)*this.estantes)
    }
}

class Cajones{
    constructor(x, y, z, cantidad){
        this.x= parseInt(x)
        this.y= parseInt(y)
        this.z= parseInt(z)
        this.cantidad=parseInt(cantidad)
    }
    supCajones(){
        return (((this.x*this.y)*3 + (this.x*this.z) + (this.y*this.z)*2))*this.cantidad 
    }
    correderas(){
        return(this.cantidad*2)
    }
}

//variables globales
let altura =prompt ("Ingresa el alto del mueble en cms");
let largo =prompt ("Ingresa la longitud del mueble en cms");
let profundidad =prompt ("Ingresa la profundidad del mueble en cms");
let estantes =prompt ("¿Cuántos estantes deseas que el mueble tenga? (no cuentes la base ni el techo como estante!");
let cantidad =prompt ("Ingresa la cantidad de cajones que deseas en tu mueble");
let y =prompt ("Ingresa el alto del cajon en cms");
let x =prompt ("Ingresa el ancho del cajon en cms");
let z =prompt ("Ingresa la profundidad del cajon en cms");


//objetos
const mueble= new Mueble (altura,largo,profundidad,estantes);
const cajones =new Cajones (x,y,z,cantidad);


//Array Fondo -> Si mantengo esto, es posible que lo reemplece por una clase, lo use para practicar arrays, la incorporación de datos con do/while y metodos. Mantendria el array con muebles prefabricados (ultimo array incluido)
const fondo=[];
let datosFondo=2
let malla = 0
let cruz = 0

do{
    llevaFondo = prompt("Queres que lleve fondo? (s/n)")
    
    if (llevaFondo=="n"){
        fondo.push(llevaFondo);
        tipoFondo=0;
        fondo.push(tipoFondo);
        break;
    } else{
        tipoFondo = prompt ("Queres que sea:\n -Metal desplegado ->Ingresá 1.\n-Cruz ->Ingresa 2");
        fondo.push(llevaFondo);
        fondo.push(tipoFondo);
    }        

}while (fondo.length !=datosFondo);

if (tipoFondo==1){
    malla= (altura * largo);
    console.log(malla);
} else if (tipoFondo==2){
    cruz=(Math.sqrt(((altura*altura) - (largo*largo))))*2;
    console.log(cruz);
}


//Array Pintura y Acabado  - metodo Join 

const pintura=[];
const terminacion=[]
let datosPintura=1;
let datosTerminacion=1;
let color=0;
let acabado=0;

do{
    colorMueble = prompt("De qué color queres pintarlo?\n -Blanco -> Ingresá 1.\n -Negro -> Ingresá 2.\n -Grafito -> Ingresá 3. ")
    
    if (colorMueble==1){
        colorMueble="blanco"
        pintura.push(colorMueble);
        break;
    } else if (colorMueble==2){
        colorMueble="negro"
        pintura.push(colorMueble);
        break;
    } else if (colorMueble==3){
        colorMueble="grafito"
        pintura.push(colorMueble);
    }
}while (pintura.length != datosPintura)


do{
    acabadoMueble =prompt("Qué tipo de acabado deseas?\n -Brillante -> Ingresá 1.\n -Satinado ->Ingresá 2.\n -Mate -> Ingresá 3.")
    
    if (acabadoMueble==1){
        acabadoMueble="brillante"
        terminacion.push(acabadoMueble);
        break;
    } else if (acabadoMueble==2){
        acabadoMueble="satinado"
        terminacion.push(acabadoMueble);
        break;
    } else if (acabadoMueble==3){
        acabadoMueble="mate"
        terminacion.push(acabadoMueble);
    }
}while (terminacion.length != datosTerminacion)



const pinturaFinal = pintura.concat(terminacion);
console.log (pinturaFinal);
console.log (pinturaFinal.join("-")); 



//Array prefabricados -> metodo sort
const prefabricados=[
    {nombre: "mesaXS", precio:17000, stock:18},
    {nombre: "mesaM", precio:20000, stock:7},
    {nombre: "mesaL", precio:23000, stock:7},
    {nombre: "estantería", precio:18000, stock:25},
    {nombre: "barra", precio:28000, stock:7},
    {nombre: "rack", precio:22000, stock:12},
]

const orden = prefabricados.sort (function(a, b){return a.precio - b.precio});

console.table(orden)


//resultados

document.write("_______________________</br>")
document.write (`El total de cms necesarios para tu mueble son ` + (mueble.perimetroTotal()+cruz)+` cms.</br>`)
document.write (`El total de cms2 de material necesarios para tus estantes es de ${mueble.superficieTotal()} cms2.</br>`)
document.write (`El mueble contara con ${cajones.cantidad} cajones y se necesitaran ${cajones.supCajones()} cms2 de material para armarlos y ${cajones.correderas()} correderas.</br>`)
document.write (`El mueble tendrá un acabado ${pinturaFinal.join("-")}.</br>`)

if (tipoFondo==0){
    document.write(`El mueble no tendá fondo.`)
} else if (tipoFondo==1){
    document.write(`El mueble tendrá un fondo en metal desplegado de ${malla} cms2.`)
}else if (tipoFondo==2){
    document.write(`El mueble tendrá un fondo tipo cruz que requerirá ${cruz} cms.`)
}
