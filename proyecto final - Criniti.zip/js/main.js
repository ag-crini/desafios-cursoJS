$(document).ready(function(){
    //-------------------------------- Inicio del Simulador ----------------------------------------
    let altura = $("#alto");
    let largo = $("#largo");
    let profundidad = $("#profundo");
    let estantes = $("#estantes");
    let cantidad = $("#cajones");
    let y = $("#cajonAlto");
    let x = $("#cajonAncho");
    let z = $("#cajonProfundo");

    //---------------------- Animaciones banner ---------------------------------------------------------
    $('.banner__div').fadeIn(3200);
    $('#logo').fadeIn(2000);   

    // ---------------------------Eventos para validar medidas/detalles/materiales del mueble----------------------------
    const botCalcular = document.querySelector("#botonCalcular");

    const validarMedidas =(e) =>{
        e.preventDefault()
        //medidas
        let altura = document.querySelector("#alto");
        let largo = document.querySelector("#largo");
        let profundidad = document.querySelector("#profundo");
        let estantes = document.querySelector("#estantes");
        let cantidad = document.querySelector("#cajones");
        let y = document.querySelector("#cajonAlto");
        let x = document.querySelector("#cajonAncho");
        let z = document.querySelector("#cajonProfundo");

        //clases y objetos
        class Mueble{
            constructor(altura, longitud, profundidad, estantes){
                this.altura= parseInt (altura);
                this.longitud= parseInt (longitud);
                this.profundidad= parseInt(profundidad);
                this.estantes= parseInt(estantes);
            }
            perimetroTotal (){
                return ((this.altura*4)+(this.longitud*4)+(this.profundidad*4)+(((this.longitud+this.profundidad)*2)*this.estantes))
            }
            superficieTotal(){
                return ((this.longitud*this.profundidad)*2+(this.longitud*this.profundidad)*this.estantes)
            }
        }

        class Cajon{
            constructor(x, y, z, cantidad){
                this.x= parseInt(x)
                this.y= parseInt(y)
                this.z= parseInt(z)
                this.cantidad=parseInt(cantidad)
            }
            supCajones(){
                return (((this.x*this.y)*3 + (this.x*this.z) + (this.y*this.z)*2))*this.cantidad 
            }
        }
        
        const mueble= new Mueble (altura.value,largo.value,profundidad.value,estantes.value);
        const cajon =new Cajon (x.value,y.value,z.value,cantidad.value);

    
        if ((altura.value==="")||(isNaN(altura.value))){
            resultados.innerHTML =`<span class="malo"> Completa la altura del mueble o chequea que sea un valor numérico.</span>`;
            altura.focus();
            return false;
        }
        if ((largo.value==="")||(isNaN(largo.value))){
            resultados.innerHTML =`<span class="malo"> Completa el ancho del mueble o chequea que sea un valor numérico.</span>`;
            largo.focus();
            return false;
        }
        if ((profundidad.value==="")||(isNaN(profundidad.value))){
            resultados.innerHTML =`<span class="malo"> Completa la profundidad del mueble o chequea que sea un valor numérico.</span>`;
            profundidad.focus();
            return false;
        }
        if ((estantes.value==="")||(isNaN(estantes.value))){
            resultados.innerHTML =`<span class="malo"> Completa la cantidad de estantes o chequea que sea un valor numérico.</span>`;
            estantes.focus();
            return false;
        }
        if ((cajones.value==="")||(isNaN(cajones.value))){
            resultados.innerHTML =`<span class="malo"> Completa la cantidad de cajones que deseas o chequea que sea un valor numérico.</span>`;
            cajones.focus();
            return false;
        }
        if ((cajonAlto.value==="")||(isNaN(cajonAlto.value))){
            resultados.innerHTML =`<span class="malo"> Completa la altura de los cajones o chequea que sea un valor numérico.</span>`;
            cajonAlto.focus();
            return false;
        }
        if ((cajonAncho.value==="")||(isNaN(cajonAncho.value))){
            resultados.innerHTML =`<span class="malo"> Completa el ancho de los cajones o chequea que sea un valor numérico.</span>`;
            cajonAncho.focus();
            return false;
        }
        if ((cajonProfundo.value==="")||(isNaN(cajonProfundo.value))){
            resultados.innerHTML =`<span class="malo"> Completa la profundidad de los cajones o chequea que sea un valor numérico.</span>`;
            cajonProfundo.focus();
            return false;
        }

        //pintura
        let blanco = document.querySelector("#white");
        let grafito = document.querySelector("#graphite");
        let negro = document.querySelector("#black");
        let brillante = document.querySelector("#shiny");
        let satinado = document.querySelector("#satin");
        let mate = document.querySelector("#matte");
        let colorFinal=0;
        let acabadoFinal=0;

        if (blanco.selected == true){colorFinal="blanco";}
        if (grafito.selected == true){colorFinal="grafito";}
        if (negro.selected == true){colorFinal="negro";}
        if (brillante.selected == true){acabadoFinal="brillante";}
        if (satinado.selected == true){acabadoFinal="satinado";}
        if (mate.selected == true){acabadoFinal="mate";}

        //material
        let madera = document.querySelector("#madera");
        let melamina = document.querySelector("#melamina");
        let material ="";

        if (madera.selected == true){material ="madera";
        } else if (melamina.selected == true){material = "melamina lisa o simil madera";}

        let costo1= mueble.perimetroTotal()*1.5
        let costo2= mueble.superficieTotal()*0.75
        let costo3= (cajones.value)*1300
        let costoTotal=costo1 + costo2 + costo3

        resultados.innerHTML=
        `
        <h3>Resultados</h3>
        <div id="secciones">
            <div id="oraciones">
                <p>El total de cms necesarios para tu mueble son ${mueble.perimetroTotal()} cms.</p>
                </br> 
                <p>El total de cms2 de ${material} necesarios para tus estantes es de ${mueble.superficieTotal()} cms2.</p>
                </br> 
                <p>El mueble tendrá ${cajones.value} cajones y necesitaran ${cajon.supCajones()} cms2 de material y ${cajones.value*2} correderas.</p>
                </br>
                <p>El mueble tendrá un acabado ${colorFinal}-${acabadoFinal}.</p>
            </div>
            <div id="presupuesto">
                <h2> El costo de producción de tu mueble es $${costoTotal} + envío.</h2>
            </div>
        </div>
        `
        return true;
    }

    botCalcular.addEventListener ("click", validarMedidas); 


    //------------ Evento limpiar valores del formulario con JQUERY -----------------------------
    
    $("#botonIntento").on("click", ()=>{
        $("#alto").val("");
        $("#largo").val("");
        $("#profundo").val("");
        $("#estantes").val("");
        $("#cajones").val("");
        $("#cajonAlto").val("");
        $("#cajonAncho").val("");
        $("#cajonProfundo").val("");

        resultados.innerHTML=``;
    });


    //--------------------------------------- Evento para validar mail de cliente-----------------------------------------

    const botMail = document.querySelector("#enviarMail");
    const mailValidar = (email) =>{
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    const validarMail =(e) =>{
        e.preventDefault()
        let mail = $("#mail");
        //const mensaje = $("#msjValidacion")

        //mail vacio
        if ($("#mail").val() ==""){
            $("#msjValidacion").html(`<span class="malo">Necesitamos tu mail para enviarte el presupuesto!</span>`);
            mail.focus();
            return false
        }
        //mail invalido
        if (!mailValidar($("#mail").val())){
            $("#msjValidacion").html(`<span class="malo">Necesitamos que ingreses un mail valido para enviarte el presupuesto!</span>`);
            mail.focus();
            return false
        }
        //mail ok
        $("#msjValidacion").html(`<span class="bueno">Listo! Nos contactaremos lo antes posible! No olvides de chequear tu casilla de correo no deseado.</span>`);
        localStorage.setItem('contactoMail', $("#mail").val());
        $("#mail").val("");

        
        return true;
        
    }

    botMail.addEventListener ("click", validarMail); 
   
    //---------------- FAQs Toggle ------------------------------------

    $('li.preguntas').on("click", function(){
    
        $(this).next().slideToggle().siblings('li.respuestas').slideUp()
    
        const icono = $(this).children("i")
        icono.toggleClass("rotacion")
        $('i').not(icono).removeClass('rotacion');
    });    
});


//------- LOG IN PARA MODIFICAR LOS PREFABRICADOS -----------
const botonLogIn = document.querySelector("#botLogIn");

const validarLogIn =(e) =>{
    e.preventDefault()
    
    if ($("#user").val() != "ADMIN" || $("#contra").val() != "ADMIN"){

        $("#divLogInResultado").html(`<div class="malo">
                                <p> Completa correctamente los campos para poder ingresar</p>
                                </div>`);
        $("#user").val("");
        $("#contra").val(""); 
        return false;           
    }

    if ($("#user").val() == "ADMIN" && $("#contra").val() == "ADMIN"){
        
        $("#divLogInResultado").html(`<div class="bueno">
                                        <p> Pudiste Ingresar</p>
                                        </div>
                                     </div>`);
        $("#user").val("");
        $("#contra").val("");
        $(".boton").show();
        $("#logOut").show();
        $("#logIn").hide();
    } 
    const hacerLogOut =(e)=>{
        $("#logOut").hide();
        $(".boton").hide();
        $("#logIn").show();
        $("#divLogInResultado").html(``)
    }
    $("#logOut").on("click",(hacerLogOut))
}

$("#botLogIn").on("click", (validarLogIn));


//-------------- Fetch / Tarjetas Prefabricados 1 ---------------------------------
let prefabricado =[];
document.addEventListener('DOMContentLoaded',()=> { consultaJson();});

function consultaJson(){
    fetch('js/data.json')
    .then (respuesta => respuesta.json())
    .then (data => prefabricado = mostrarTarjetas(data.prefabricados));
}    
    
function mostrarTarjetas (tarjetas){
    tarjetas.forEach (tarjeta =>{
        $("#divPrefabricados").append(
            `<div class="card" id="prefabricado${tarjeta.id}">
                <button type="submit" id="encender${tarjeta.id}" class="boton" style="display:none;">Activar descuento</button>
                <button type="submit" id="apagar${tarjeta.id}" class="boton" style="display:none;">Desactivar descuento</button>
                <div id="info">
                <h3>${tarjeta.nombre}</h3>
                <p id="sinPromo${tarjeta.id}">Precio: $${tarjeta.precio}</p>
                <p id="promo${tarjeta.id}" style="display:none;" class="promo">Precio: $${tarjeta.precio2}</p>
                <p>Stock:${tarjeta.stock} unid.</p>
                </div>
                <img src="${tarjeta.img}">
            </div>`);

        $(`#encender${tarjeta.id}`).on("click",function(){
            $(`#prefabricado${tarjeta.id}`).append(`<img src="img/sale1.png" class="sale">`)
            $(`#promo${tarjeta.id}`).show();
            $(`#sinPromo${tarjeta.id}`).addClass("sinPromo");
        });

        $(`#apagar${tarjeta.id}`).on("click",function(){
            $(`#prefabricado${tarjeta.id} .sale`).remove()
            $(`#promo${tarjeta.id}`).hide();
            $(`#sinPromo${tarjeta.id}`).removeClass("sinPromo");
        });

    })

}
//-------------- Fetch / Tarjetas Prefabricados 2 ---------------------------------
let prefabricado2 =[];
document.addEventListener('DOMContentLoaded',()=> { consultaJson2();});

function consultaJson2(){
    fetch('js/data.json')
    .then (respuesta2 => respuesta2.json())
    .then (data2 => prefabricado2 = mostrarTarjetas2(data2.prefabricados2));
};   
    
function mostrarTarjetas2 (tarjetas2){
    tarjetas2.forEach (tarjeta2 =>{
        $("#divPrefabricados2").append(
            `<div class="card" id="prefabricado${tarjeta2.id}">
                <button type="submit" id="encender${tarjeta2.id}" class="boton"  style="display:none;">Activar descuento</button>
                <button type="submit" id="apagar${tarjeta2.id}" class="boton"  style="display:none;">Desactivar descuento</button>
                <div id="info">
                    <h3>${tarjeta2.nombre}</h3>
                    <p id="sinPromo${tarjeta2.id}">Precio: $${tarjeta2.precio}</p>
                    <p id="promo${tarjeta2.id}" style="display:none;" class="promo">Precio: $${tarjeta2.precio2}</p>
                    <p>Stock:${tarjeta2.stock} unid.</p>
                </div>
                <img src="${tarjeta2.img}">
            </div>`);

        $(`#encender${tarjeta2.id}`).on("click",function(){
            $(`#prefabricado${tarjeta2.id}`).append(`<img src="img/sale1.png" class="sale">`)
            $(`#promo${tarjeta2.id}`).show();
            $(`#sinPromo${tarjeta2.id}`).addClass("sinPromo");
        });

        $(`#apagar${tarjeta2.id}`).on("click",function(){
            $(`#prefabricado${tarjeta2.id} .sale`).remove();
            $(`#promo${tarjeta2.id}`).hide();
            $(`#sinPromo${tarjeta2.id}`).removeClass("sinPromo");
        });
    })
};