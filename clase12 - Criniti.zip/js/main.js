$(document).ready(function(){

    //-------------------------------- Inicio del Simulador ----------------------------------------

    let altura = $("#alto");
    let largo = $("#largo");
    let profundidad = $("#profundo");
    let estantes = $("#estantes");
    let cantidad = $("#cajones");
    let y = $("#cajonAlto");
    let x = $("#cajonAncho");
    let z = $("#cajonProfundo");


    //-----------------------Array prefabricados -------------------------------/ DOM - creacion desde array usando escritura JQUERY

    const prefabricados=[
        {id:"mesaS", nombre: "Mesa Cuyo S", precio:17000, stock:18, img:"img/mesa-xs.jpg"},
        {id:"mesaM", nombre: "Mesa Cuyo M", precio:20000, stock:9, img:"img/mesa-m.jpg"},
        {id:"mesaL", nombre: "Mesa Cuyo L", precio:23000, stock:7, img:"img/mesa-l.jpg"},
        {id:"estanteria", nombre: "Estantería Norteña", precio:18000, stock:25, img:"img/estanteria.jpg"},
        {id:"barra", nombre: "Barra Patagónica", precio:28000, stock:5, img:"img/barra.jpg"},
        {id:"rack", nombre: "Rack Pampeano", precio:22000, stock:12, img:"img/rack.jpg"},
        {id:"estante-cocina", nombre: "Estantes Litoral", precio:22000, stock:14, img:"img/estante-cocina.jpg"},
        {id:"banqueta", nombre: "Banqueta Rosario", precio:22000, stock:12, img:"img/banqueta.jpg"},
    ]

    //metodo sort
    const orden = prefabricados.sort (function(a, b){return a.precio - b.precio});
    console.table(orden);

    //DOM - creacion
    const divPrefabricados = document.querySelector('#divPrefabricados');


    //Agrega una card r por funcion una etiqueta a los productos en promocion - todavia no disponible. 

    for (const articulo of prefabricados){
        $("#divPrefabricados").append(
            `<div class="card" id="prefabricado${articulo.id}">
                <button type="submit" id="encender${articulo.id}" class="boton">Activar descuento</button>
                <button type="submit" id="apagar${articulo.id}" class="boton">Desactivar descuento</button>
                <div>
                    <h3>${articulo.nombre}</h3>
                    <p>Precio: $${articulo.precio}.</br>Stock:${articulo.stock} unid. 
                </div>
                <img src="${articulo.img}">
            </div>`);


        
        $(`#encender${articulo.id}`).on("click",function(){
            $(`#prefabricado${articulo.id}`).append(`<img src="img/sale1.png" class="sale">`)
        });

        $(`#apagar${articulo.id}`).on("click",function(){
            $(`#prefabricado${articulo.id} .sale`).remove()
        });
        
    }
    
    


    // ---------------------------Eventos para validar medidas/detalles/materiales del mueble----------------------------


    const botCalcular = document.querySelector("#botonCalcular");

    const validarMedidas =(e) =>{
        e.preventDefault()
        //medidas
        let altura = document.querySelector("#alto");
        let largo = document.querySelector("#largo");
        let profundidad = document.querySelector("#profundo");
        let estantes = document.querySelector("#estantes");
        let cajones = document.querySelector("#cajones");
        let y = document.querySelector("#cajonAlto");
        let x = document.querySelector("#cajonAncho");
        let z = document.querySelector("#cajonProfundo");

        //clases y objetos
        class Mueble{
            constructor(altura, longitud, profundidad, estantes, cajones){
                this.altura= parseInt (altura);
                this.longitud= parseInt (longitud);
                this.profundidad= parseInt(profundidad);
                this.estantes= parseInt(estantes);
            }
            perimetroTotal (){
                return ((this.altura*4)+(this.longitud*4)+(this.profundidad*4)+(((this.longitud+this.profundidad)*2)*this.estantes))
            }
            superficieTotal(){
                return ((this.longitud*this.profundidad)*2+(this.longitud*this.profundidad)*this.estantes)
            }
        }
        class Cajon{
            constructor(x, y, z, cantidad){
                this.x= parseInt(x)
                this.y= parseInt(y)
                this.z= parseInt(z)
                this.cantidad=parseInt(cantidad)
            }
            supCajones(){
                return (((this.x*this.y)*3 + (this.x*this.z) + (this.y*this.z)*2))*this.cantidad 
            }
        }
        
        const mueble= new Mueble (altura.value,largo.value,profundidad.value,estantes.value);
        const cajon =new Cajon (x.value,y.value,z.value,cantidad.value);

    
        if ((altura.value==="")||(isNaN(altura.value))){
            resultados.innerHTML =`<span class="malo"> Completa la altura del mueble o chequea que sea un valor numérico.</span>`;
            altura.focus();
            return false;
        }
        if ((largo.value==="")||(isNaN(largo.value))){
            resultados.innerHTML =`<span class="malo"> Completa el ancho del mueble o chequea que sea un valor numérico.</span>`;
            largo.focus();
            return false;
        }
        if ((profundidad.value==="")||(isNaN(profundidad.value))){
            resultados.innerHTML =`<span class="malo"> Completa la profundidad del mueble o chequea que sea un valor numérico.</span>`;
            profundidad.focus();
            return false;
        }
        if ((estantes.value==="")||(isNaN(estantes.value))){
            resultados.innerHTML =`<span class="malo"> Completa la cantidad de estantes o chequea que sea un valor numérico.</span>`;
            estantes.focus();
            return false;
        }
        if ((cajones.value==="")||(isNaN(cajones.value))){
            resultados.innerHTML =`<span class="malo"> Completa la cantidad de cajones que deseas o chequea que sea un valor numérico.</span>`;
            cajones.focus();
            return false;
        }
        if ((cajonAlto.value==="")||(isNaN(cajonAlto.value))){
            resultados.innerHTML =`<span class="malo"> Completa la altura de los cajones o chequea que sea un valor numérico.</span>`;
            cajonAlto.focus();
            return false;
        }
        if ((cajonAncho.value==="")||(isNaN(cajonAncho.value))){
            resultados.innerHTML =`<span class="malo"> Completa el ancho de los cajones o chequea que sea un valor numérico.</span>`;
            cajonAncho.focus();
            return false;
        }
        if ((cajonProfundo.value==="")||(isNaN(cajonProfundo.value))){
            resultados.innerHTML =`<span class="malo"> Completa la profundidad de los cajones o chequea que sea un valor numérico.</span>`;
            cajonProfundo.focus();
            return false;
        }

        //pintura
        let blanco = document.querySelector("#white");
        let grafito = document.querySelector("#graphite");
        let negro = document.querySelector("#black");
        let brillante = document.querySelector("#shiny");
        let satinado = document.querySelector("#satin");
        let mate = document.querySelector("#matte");
        let colorFinal=0;
        let acabadoFinal=0;

        if (blanco.selected == true){
            colorFinal="blanco";
        }
        if (grafito.selected == true){
            colorFinal="grafito";
        }
        if (negro.selected == true){
            colorFinal="negro";
        }
        if (brillante.selected == true){
            acabadoFinal="brillante";
        }
        if (satinado.selected == true){
            acabadoFinal="satinado";
        }
        if (mate.selected == true){
            acabadoFinal="mate";
        }

        //material
        let madera = document.querySelector("#madera");
        let melamina = document.querySelector("#melamina");
        let material ="";

        if (madera.selected == true){
            material ="madera";
        } else if (melamina.selected == true){
            material = "melamina lisa o simil madera";
        }

        resultados.innerHTML=
        `<p>El total de cms necesarios para tu mueble son ` + (mueble.perimetroTotal())+` cms.</p>
        </br> 
        <p>El total de cms2 de ${material} necesarios para tus estantes es de ${mueble.superficieTotal()} cms2.</p>
        </br> 
        <p>El mueble contara con ${cajones.value} cajones y se necesitaran ${cajon.supCajones()} cms2 de material para armarlos y ${cajones.value*2} correderas.</p>
        </br>
        <span>El mueble tendrá un acabado ${colorFinal}-${acabadoFinal}.</span>`
        
        return true;
    }

    botCalcular.addEventListener ("click", validarMedidas); 


    //------------ Evento limpiar valores del formulario con JQUERY -----------------------------
    
    $("#botonIntento").on("click", ()=>{
        $("#alto").val("");
        $("#largo").val("");
        $("#profundo").val("");
        $("#estantes").val("");
        $("#cajones").val("");
        $("#cajonAlto").val("");
        $("#cajonAncho").val("");
        $("#cajonProfundo").val("");
    });


    //--------------------------------------- Evento para validar mail de cliente-----------------------------------------

    const botMail = document.querySelector("#enviarMail");
    const mailValidar = (email) =>{
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    const validarMail =(e) =>{
        e.preventDefault()
        let mail = $("#mail");
        //const mensaje = $("#msjValidacion")

        //mail vacio
        if ($("#mail").val() ==""){
            $("#msjValidacion").html(`<span class="malo">Necesitamos tu mail para enviarte el presupuesto!</span>`);
            mail.focus();
            return false
        }
        //mail invalido
        if (!mailValidar($("#mail").val())){
            $("#msjValidacion").html(`<span class="malo">Necesitamos que ingreses un mail valido para enviarte el presupuesto!</span>`);
            mail.focus();
            return false
        }
        //mail ok
        $("#msjValidacion").html(`<span class="bueno">Listo! Nos contactaremos lo antes posible! No olvides de chequear tu casilla de correo no deseado.</span>`);
        $("#mail").val("");
        return true;
        
    }

    botMail.addEventListener ("click", validarMail); 



    //------- LOG IN PARA MODIFICAR LOS PREFABRICADOS -----------

    const botonLogIn = document.querySelector("#botLogIn");

    const validarLogIn =(e) =>{
        e.preventDefault()
        let user = document.querySelector("#user");
        let pass = document.querySelector("#contra");

        if ($("#user").val() == "ADMIN" && $("#contra").val() == "ADMIN"){
            
            $("#divLogInResultado").html(`<div class="bueno">
                                <p> Pudiste Ingresar</p>
                            </div>`);
            $("#user").val("");
            $("#contra").val(""); 
            return true;
        } 
        
        if ($("#user").val() != "ADMIN" || $("#contra").val() != "ADMIN"){

            $("#divLogInResultado").html(`<div class="malo">
                                    <p> Completa correctamente los campos para poder ingresar</p>
                                    </div>`);
            $("#user").val("");
            $("#contra").val(""); 
            return false;           
        }
    }

    $("#botLogIn").on("click", (validarLogIn));

});